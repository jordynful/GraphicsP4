import java.awt.FlowLayout;
import java.awt.*;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.util.Random;
import javax.swing.*;
import java.io.*;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.lang.Math;
/**
 * 2D rotation program
 */
public class App extends JPanel {
    private BufferedImage canvas;
    
     //Got this part of the code from https://stackoverflow.com/questions/3325546/how-to-color-a-pixel
    public App(int width, int height) throws FileNotFoundException, InterruptedException {
       
        canvas = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
       loop();
        // test();
    
    }

    public void test() {
        double[][] A= {{1,1,1},{2,2,2},{3,3,3}};
        double[][] B = {{1,0,0},{0,1,0},{0,0,1}};
        double[][] C = {{0,0,0},{0,0,0},{0,0,0}};
        matrixMultiply(A, B, C);
    }

    public void loop() throws FileNotFoundException, InterruptedException {
        boolean cont = true;
        Scanner keyboard = new Scanner(System.in);
        // drawGraph();
        // while (cont) {
        drawGraph();
        int user;
        System.out.println("Enter 1 to transform 3D objects and 2 to quit");
        user = keyboard.nextInt();
        keyboard.nextLine();
        if (user == 1) {
        System.out.println("Enter the name of the file: ");
       
        String n = keyboard.nextLine();
        System.out.println("Enter the name of the file for output: ");
        String f = keyboard.nextLine();
        System.out.println("Enter the viewpoint x value");
        double xE = keyboard.nextDouble();
        System.out.println("Enter the viewpoint y value");
        double yE = keyboard.nextDouble();
        System.out.println("Enter the viewpoint z value");
        double zE = keyboard.nextDouble();
        System.out.println("Enter the screen size");
        double screenSize = keyboard.nextDouble();
        System.out.println("Enter the distance from the screen");
        double delta = keyboard.nextDouble();

        System.out.println("What kind of transformation do you wish to perform?\n 1-Translation 2-BasicScale 3-BasicRotation (x-axis) 4-BasicRotation (y-axis) 5-BasicRotation (z-axis) 6-scale ");
        int transformation = keyboard.nextInt();

        double[][] mat = {{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}};

        if (transformation == 1) {
            System.out.println("Enter the X translation value:");
            double x = keyboard.nextDouble();
          
            System.out.println("Enter the Y translation value:");
            double y = keyboard.nextDouble();

            System.out.println("Enter the Z translation value:");
            double z = keyboard.nextDouble();
            mat = basicTranslate(x, y, z);
            
        }

        else if (transformation == 2) {
            System.out.println("Enter the X scale value:");
            double x = keyboard.nextDouble();
            System.out.println("Enter the Y scale value:");
            double y = keyboard.nextDouble();
            System.out.println("Enter the Z scale value:");
            double z = keyboard.nextDouble();
            mat = basicScale(x, y, z);
        }
        else if (transformation == 3) {
            System.out.println("Enter the angle of rotation");
            double angle = keyboard.nextDouble();
            mat = basicRotateX(angle);
        }
        else if (transformation == 4) {
            System.out.println("Enter the angle of rotation");
            double angle = keyboard.nextDouble();
            mat = basicRotateY(angle);
        }
        else if (transformation == 5) {
            System.out.println("Enter the angle of rotation");
            double angle = keyboard.nextDouble();
            mat = basicRotateZ(angle);
        }
        else if (transformation == 6) {
            System.out.println("Enter the X scale value:");
            double x = keyboard.nextDouble();
            System.out.println("Enter the Y scale value:");
            double y = keyboard.nextDouble();

            System.out.println("Enter the Z scale value:");
            double z = keyboard.nextDouble();

            System.out.println("Enter the X center value:");
            double xc = keyboard.nextDouble();
            System.out.println("Enter the Y center value:");
            double yc = keyboard.nextDouble();
            System.out.println("Enter the Z center value:");
            double zc = keyboard.nextDouble();
            mat = scale(x, y, z, xc, yc, zc);
        }
        inputLines(n,0,xE,yE,zE,screenSize,delta);
        applyTransformation(mat, n, f,xE,yE,zE,screenSize,delta);
        // Thread.sleep(1000);
        
        // }
    //     else {
    // //    keyboard.skip(".*");
    // // System.exit(0);
    // cont = false;
    //     }
    }
        keyboard.close();
    
    }

    public double[] projection( double x,double y, double z, double xE, double yE,double zE,double screenSize,double delta) {
        double[][] arr = {{x},{y},{z},{1}};
        double commonSq = Math.sqrt(((xE*xE) + (yE*yE)));
        double commonSq2 = Math.sqrt((zE*zE) + (commonSq));
        double xeSq = xE/(commonSq);
        double yeSq = yE/(commonSq);
        double zSq1 = commonSq/commonSq2;
        double zSq2 = zE/commonSq2;
        double [][] mat = {{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}};
        double [][] t1 = {{1,0,0,0},{0,0,1,0},{0,-1,0,0},{0,0,0,1}};
        double [][] t2 = {{1,0,0,-xE},{0,1,0,-yE},{0,0,1, -zE},{0,0,0,1}};

        double [][] t3 = {{-yeSq,0,-xeSq,0},{0,1,0,0},{xeSq,0,-yeSq,0},{0,0,0,1}};

        double [][] t4 = {{1,0,0,0},{0,zSq1,-zSq2,0},{0,zSq2,zSq1, 0},{0,0,0,1}};
        double [][] N = {{delta/screenSize,0,0,0},{0,delta/screenSize,0,0},{0,0,1, 0},{0,0,0,1}};
        mat = matrixMultiply(t1, t2, mat);
        mat = matrixMultiply(mat, t3, mat);
        mat = matrixMultiply(mat, t4, mat);
        mat = matrixMultiply(mat, N, mat);

        arr = matrixMultiply(arr, mat, arr);
        double [] ans = {arr[0][0], arr[1][0]};
        
        //perspective projection code here...
      
        return ans;
    }

    public double xProjection( double x,double z) {

        //perspective projection code here...
        double xs = ((60 * x)/(15 * z))*(200) + 200;
        return xs;
    }

    public double yProjection(double y, double z) {

        //perspective projection code here...
        double ys = ((60 * y)/(15 * z))*(200) + 200;
        return ys;

    }

    public int inputLines(String dataLines, int num, double xE, double yE,double zE,double screenSize,double delta) throws FileNotFoundException {
        Scanner scanner2 = new Scanner(new File(dataLines));
        double x0;
        double y0;
        double z0;
        double x1;
        double y1;
        double z1;
        int col = Color.BLACK.getRGB();
        while(scanner2.hasNextLine()) {
           
            num++;
            String data = scanner2.nextLine();
            StringTokenizer tokenizer = new StringTokenizer(data);
            String tok = tokenizer.nextToken();
            x0 = Double.parseDouble(tok);
            tok = tokenizer.nextToken();
            y0 = Double.parseDouble(tok);

            tok = tokenizer.nextToken();    
            z0 = Double.parseDouble(tok);

            tok = tokenizer.nextToken(); 
            x1 = Double.parseDouble(tok);
            tok = tokenizer.nextToken();
            y1 = Double.parseDouble(tok);
            tok = tokenizer.nextToken();    
            z1 = Double.parseDouble(tok);
            double [] arr0 = projection(x0,y0,z0,xE,yE,zE,screenSize,delta);
            double [] arr1 = projection(x1,y1,z1,xE,yE,zE,screenSize,delta);
            x0 = arr0[0];
            y0 = arr0[1];

            x1 = arr1[0];
            y1 = arr1[1];

            displayPixels((int)x0, (int)y0, (int)x1, (int)y1, col);

        }

        scanner2.close();
        return num;
        
    }


    public void applyTransformation(double[][] matrix, String dataLines, String fileProvided,  double xE, double yE,double zE,double screenSize,double delta) throws FileNotFoundException {
        Scanner scanner2 = new Scanner(new File(dataLines));
        // System.out.print("wtf");
        
        double x0;
        double y0;
        double z0;
        double x1;
        double y1;
        double z1;
        int col = Color.BLUE.getRGB();
        while(scanner2.hasNextLine()) {
            String data = scanner2.nextLine();
            StringTokenizer tokenizer = new StringTokenizer(data);
            String tok = tokenizer.nextToken();
            x0 = Double.parseDouble(tok);
            tok = tokenizer.nextToken();
            y0 = Double.parseDouble(tok);
            tok = tokenizer.nextToken();
            z0 = Double.parseDouble(tok);
            tok = tokenizer.nextToken();
            x1 = Double.parseDouble(tok);
            tok = tokenizer.nextToken();
            y1 = Double.parseDouble(tok);
            tok = tokenizer.nextToken();
            z1 = Double.parseDouble(tok);

            double[][] start = {{x0}, {y0}, {z0}, {1}};
            double[][] end = {{x1}, {y1}, {z1},{1}};
            double[][] C = {{0,0,0,0},{0,0,0,0},{0,0,0,0}, {0,0,0,0}};
            double[][] B = {{0,0,0,0},{0,0,0,0},{0,0,0,0}, {0,0,0,0}};
            // System.out.println("About to multiply start");


            start = matrixMultiply(start, matrix, B);
            end = matrixMultiply(end, matrix, C);
      
            double x02 = start[0][0];
            double y02 = start[1][0];
            double z02 = start[2][0];
         
            double x12 = end[0][0];
            double y12 = end[1][0];
            double z12 = end[2][0];


            double [] arr0 = projection(x02,y02,z02,xE,yE,zE,screenSize,delta);
            double [] arr1 = projection(x12,y12,z12,xE,yE,zE,screenSize,delta);
            x02 = arr0[0];
            y02 = arr0[1];

            x12 = arr1[0];
            y12 = arr1[1];


            String dataLine = String.valueOf(x02) + ' ' + String.valueOf(y02) + ' ' + String.valueOf(x12) + ' ' + String.valueOf(y12) + "\n";
            //multiply matrix to x y and x1 y1
            //call output lines with a string with those data points
            //display pixels
            outputLines(0, dataLines, dataLine, fileProvided);

            //need to put projection here before display pixels...
            displayPixels((int)x02, (int)y02, (int)x12, (int)y12, col);
        }
        scanner2.close();
        
    }
    public void outputLines(int num, String dataLines, String lineToaAdd, String fileProvided) {
        try {
            File file = new File(fileProvided);
            if (!file.exists()) { 
                file.createNewFile(); 
            }
            FileWriter writer = new FileWriter(file, true); 

            writer.write(lineToaAdd); // write data to file
            writer.close(); // close the FileWriter

        } catch (IOException e) {

            e.printStackTrace();
        }
        
    }
    public double[][] matrixMultiply(double[][] A, double[][] B, double[][] C) {
        // System.out.println("A length of col: " + A[0].length);
        // System.out.println("A length of rows: " + A.length);
        // System.out.println("B length of col: " + B[0].length);
        // System.out.println("B length of rows: " + B.length);
        for (int i = 0; i < A[0].length; i++) { //col of A
            for (int j = 0; j < B.length; j++) {//row of B
               
                double sum = 0;
                    for (int k = 0; k < A.length; k++) {//row of A

                    sum+= A[k][i]*B[j][k];
                    }
                C[j][i] = sum;
               
              
            }

        }
     
        return C;
    }

    public double[][] basicTranslate(double Tx, double Ty, double Tz) {
        double[][] matValues = {{1,0,0,Tx}, {0,1,0,Ty}, {0,0,1,Tz},{0,0,0,1}};
        return matValues;
    }

    public double[][] basicScale(double Sx, double Sy, double Sz) {
        double[][] matValues = {{Sx,0,0,0}, {0,Sy,0,0},{0,0,Sz,0}, {0,0,0,1}};
       
        return matValues;
    }

    public double[][] basicRotateY(double angle) {
        angle = Math.toRadians(angle);
        double[][] matValues = {{Math.cos(angle),0, Math.sin(angle),0}, {0,1,0,0},{-Math.sin(angle),0, Math.cos(angle),0}, {0,0,0,1}};
        
        return matValues;
        
    }

    public double[][] basicRotateZ(double angle) {
        angle = Math.toRadians(angle);
        double[][] matValues = {{Math.cos(angle),-Math.sin(angle), 0,0}, { Math.sin(angle),Math.cos(angle),0,0},{0,0, 1,0}, {0,0,0,1}};
        
        return matValues;
        
    }

    public double[][] basicRotateX(double angle) {
        angle = Math.toRadians(angle);
        double[][] matValues = {{1,0, 0,0}, {0,Math.cos(angle),-Math.sin(angle),0},{0,Math.sin(angle), Math.cos(angle),0}, {0,0,0,1}};
        
        return matValues;
        
    }

    public double[][] scale(double Sx, double Sy, double Sz, double Cx, double Cy, double Cz ) {
        double[][] mat = {{0,0,0,0},{0,0,0,0},{0,0,0,0}, {0,0,0,0}};
        double[][] translateToCenter = basicTranslate(-Cx, -Cy, -Cz);
        double[][] scale = basicScale(Sx,Sy, Sz);
        double[][] translateBack = basicTranslate(Cx, Cy, Cz);
        double[][] product = matrixMultiply(translateToCenter, scale,mat);
        product = matrixMultiply(product, translateBack, mat);
        
        return  product;
    }


    public Dimension getPreferredSize() {
        return new Dimension(canvas.getWidth(), canvas.getHeight());
    }
    //Got this part of the code from https://stackoverflow.com/questions/3325546/how-to-color-a-pixel
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.drawImage(canvas, null, null);
        
    }

    
    public void drawPoint(int x, int y, int col) {
        //Graph starts at x=10 y=380
        // System.out.println("x " + x + " y " + y);
        if (x < 190 && y < 190 && x > -190 && y > -190) {
            
        x = x + 190;
        y = 190 - y;
        canvas.setRGB(x, y, col);
        // System.out.println("writing a coordinate");
        repaint();

        
        }
    } 


//Got this part of the code from https://stackoverflow.com/questions/3325546/how-to-color-a-pixel
    public void fillCanvas(Color c) {
        int color = c.getRGB();
        for (int x = 0; x < canvas.getWidth(); x++) {
            for (int y = 0; y < canvas.getHeight(); y++) {
                canvas.setRGB(x, y, color);
            }
        }
        repaint();
    }

    public void drawGraph() {
        int color = Color.BLACK.getRGB();
        for (int x = 0; x < canvas.getWidth(); x++) {
            canvas.setRGB(x, 190, color);
        }
        for (int y = 0; y < canvas.getHeight(); y++) {
            canvas.setRGB(190, y, color);
        }

    }



    public void displayPixels(int x0, int y0, int x1, int y1, int col) {
        //Used only notes from class to build these algorithms
        double dX = x1 - x0;
        double dY = y1 - y0;


        if (dX > 0 && dY>=0 && Math.abs(dX)>=Math.abs(dY)) {

            double m = dY/dX;
            double start = System.nanoTime();
            double end;
            for (int i = 0; i < dX; i++) {
                int x = x0 + i;
                double y = (m*i) + y0;
                drawPoint(x, (int)y, col);
            }
            end = System.nanoTime();
       
            
  

        }
        else if (dX >= 0 && dY>0 && Math.abs(dX)<Math.abs(dY)) {

            double m = dX/dY;
            double start = System.nanoTime();
            double end;
            for (int i = 0; i < dY; i++) {
                int y = y0 + i;
                double x = (m*i) + x0;
                drawPoint((int)x, y, col);
            }
            end = System.nanoTime();
      

        }


        /**
         * DX negative, DY positive, DX > DY and DX < DY
         */
        else if (dX < 0 && dY>=0 && Math.abs(dX)>=Math.abs(dY)) {
            double m = dY/dX;
            drawPoint(x1, y1, col);
            for (int i = 0; i < -dX; i++) {
                int x = x1 + i;
                double y = (m*i) + y1;
                drawPoint(x, (int)y, col);
            }
           


        }

        else if (dX < 0 && dY>0 && Math.abs(dX)< Math.abs(dY)) {
            double m = dX/dY;

            drawPoint(x1, y1, col);
            for (int i = 0; i < dY; i++) {
                int y = y1 - i;
                double x = x1 - (m*i);
                drawPoint((int)x, y, col);
            }

        }

        /**
         * DX positive, DY negative, DX > DY and DX < DY
         */
        else if (dX > 0 && dY < 0 && Math.abs(dX)>=Math.abs(dY)) {
            double m = dY/dX;
            double start = System.nanoTime();
            double end;
            for (int i = 0; i < dX; i++) {
                int x = x0 + i;
                double y = y0 + (m*i);
                drawPoint(x, (int)y, col);
            }
            end = System.nanoTime();

        }

        else if (dX >= 0 && dY < 0 && Math.abs(dX)<Math.abs(dY)) {
            double m = dX/dY;
            double start = System.nanoTime();
            double end;
            for (int i = 0; i < -dY; i++) {
                int y = y1 + i;
                double x = (m*i) + x1;
                drawPoint((int)x, y, col);
            }
            end = System.nanoTime();

        }

        /**
         * DX negative, DY negative, DX > DY and DX < DY
         */
        else if (dX < 0 && dY < 0 && Math.abs(dX)>=Math.abs(dY)) {
            double m = dY/dX;
            double start = System.nanoTime();
            double end;
            for (int i = 0; i < -dX; i++) {
                int x = x1 + i;
                double y = y1 + (m*i) ;
                drawPoint(x, (int)y, col);
            }
  

        }


        else if (dX < 0 && dY < 0 && Math.abs(dX)< Math.abs(dY)) {

            double m = dX/dY;
            double start = System.nanoTime();
            double end;
            for (int i = 0; i < -dY; i++) {
                int y = y1 + i;
                double x = x1 + (m*i) ;
                drawPoint((int)x, y, col);
            }


        }
        
    }


    public static void main(String[] args) throws FileNotFoundException, InterruptedException 
    {
        
        //Got this part of the code from https://stackoverflow.com/questions/3325546/how-to-color-a-pixel
        int width = 400;
        int height = 400;
        
        JFrame f = new JFrame("Display Graphic Drawings");


        App d = new App(width, height);
        f.add(d);
        f.pack();
        
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setLocationRelativeTo(null);
        f.setVisible(true);
        f.setResizable(false);

    }
}